export const environment = {
  production: true,
  Baseurl:  'http://localhost:3000/core'
};
