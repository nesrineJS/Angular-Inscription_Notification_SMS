import { Component, OnInit, ViewEncapsulation, ViewChild,Inject} from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators, AbstractControl} from '@angular/forms';
import { FormsService } from './forms.service';
enum CheckBoxType { MODIFY_MARIE, MODIFY_CELEBATAIRE, NONE };
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
//import { AlertDialogComponent } from '../alert-dialog/alert-dialog.component';
import 'rxjs/add/operator/distinctUntilChanged';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-forms-page',
  templateUrl: './forms.component.html',
  styleUrls: ['./forms.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class FormsComponent implements OnInit {

  values = '';
  userDetailsForm: FormGroup;
  userCheckForm: FormGroup;

  isDisabled :boolean=true;

  selected=-1;
  selectedCivility=-1;
  secteur:any
  state:any;
  codeInscription:any;
  fullname:any;
  msisdn:any;
  service:any;
  civility:any;
  job:any;
  gender:any;
  param_1:any;
  param_2:any;
  param_3:any;
  param_4:any;
  lang:any;
  city:any;
  zip_code:any;
  date_birth:any;

  code:any;
  id_code:any;
  countries:any;
  libelle:any;

  code_check:any;
  code_msisdn:any;

  Genders = ['ذكر','أنثى']

  //lstChecked: string = ";";

  InscriptionBack : boolean= false;
  InscriptionCode : boolean=false;

  unChecked: Boolean=false;
  id:any
  value = 1;
  txt="Your inscription has been saved ! Please check your code."

  /*secteurs = [
    "Transport",
    "Carburant", 
    "Secteur public", 
   "Education",
    "Tout"
    ];*/

  _code:any;
  _msisdn:any;
  closeResult: string;

  animal: string;
  name: string;
  codeObj:any;

  
  constructor(private fb: FormBuilder, private rest: FormsService,public dialog: MatDialog, private datePipe: DatePipe) {}

   /* initForm() {
      this.userDetailsForm = this.fb.group({
        'input' : ['value' + this.value++]
      });
    }
    
    onDisable(init: boolean) {
      if (init)
        this.initForm();
      this.userDetailsForm.disable();
    }

    onEnable(init: boolean) {
      if (init)
        this.initForm();
      this.userDetailsForm.enable();
    }*/

    ngOnInit() {

      this.createForms();     

    }
   
    /*ShowState(state){
       this.state=state;
    }*/

    ShowGender(gender){
      this.gender=gender;
   }

    /*ShowSecteur(secteur,event){
       this.secteur=secteur;
        this.lstChecked = this.lstChecked + secteur + ";"
        console.log(this.lstChecked)
    }*/


    GetInscriptionInsert()  {
      
      this.service='horoscope'
      this.param_2='';
      this.param_3='';
      this.param_4='';
      this.lang ='';
      this.param_1='';
      this.state='';
      this.job='';
      this.date_birth=this.datePipe.transform(this.date_birth, 'yyyy-MM-dd 00:00:00').toString();
      console.log('1 before:'+this.date_birth)

      this.code_msisdn = this.msisdn;

      this.rest.InscriptionInsert(this.fullname,this.msisdn,this.service,this.state,this.job,this.gender, this.param_1, 
          this.param_2, this.param_3, this.param_4,this.lang,this.city,this.zip_code, this.date_birth).subscribe(respond => {
            console.log(respond)
            this.id_code=respond[0].id_code
            this.msisdn=respond[0].msisdn

            console.log('2 after:'+this.date_birth)


          this.rest.SendCodeBySMS(respond[0].msisdn,respond[0].id_code ).subscribe(respond2 => { console.log(respond2)}); 
        });
       this.InscriptionBack =true;
      }  

   /* GetCodeCheck()  {
    
      this.rest.CodeCheck(this.code_check,this.code_msisdn).subscribe(respond => {
        console.log(respond)
      });
    }  */ 

    GetCodeCheck2(code, mobile)  {
    
      this.rest.CodeCheck(code,mobile).subscribe(respond => {
        console.log(respond)
      });
      
      this.InscriptionCode =true;
    
    }   

    /*show(state){
      console.log(state)
    }*/

    /*GetCountrySearch(event: any)  {
      this.values='';
      this.values=this.values + event.target.value;
      this.rest.CountrySearch( this.values).subscribe(respond => {
        this.countries = respond;

      } )
    }  */ 
  

    GetCountrySearch(event: any)  {
    
      //this.values+event.target.value ;
          
       this.rest.CountrySearch( this.values+event.target.value ).subscribe(respond => {
         this.countries=respond;
       
       })
     }

  /*  selectedCity(libelle){
     this.libelle = libelle
    }*/

    createForms() {

      this.userDetailsForm = this.fb.group({
        fullname: ['', Validators.required ],
        city: ['', Validators.required],
        zip_code: ['', Validators.required],
        date_birth: ['', Validators.required],
        msisdn: ['', Validators.required],
        //secteur: new FormControl(false,  Validators.pattern('true')),
        gender: new FormControl(false, Validators.pattern('true')),
        terms: new FormControl(false, Validators.pattern('true'))

      });

    }
  
    validation_messages = {
      'fullname': [
        { type: 'required', message: 'الإسم الكامل ضروري' },
      ],
      'city': [
        { type: 'required', message: 'المدينة مطلوبة' },
      ],
      'zip_code': [
        { type: 'required', message: 'الرمز البريدي مطلوب' },
      ],
      'date_birth': [
        { type: 'required', message: 'تاريخ الميلاد مطلوب' },
      ],
      'msisdn': [
        { type: 'required', message: 'مطلوب المحمول' },
    
      ],
     /* 'secteur': [
        { type: 'pattern', message: 'Secteur is required phone number must starts with 216' },
    
      ],*/
      'terms': [
        { type: 'pattern', message: 'يجب عليك قبول الشروط والأحكام' }
      ],
      'gender': [
        { type: 'pattern', message: 'يجب عليك اختيار جنسك' }
      ]
    };
   
}

